var express = require('express');
var router = express.Router();
var path = require('path');

router.post('/classify', function(req, res, next) {
  // DON'T return the hardcoded response after implementing the backend
  // let success = ["image upload successful"];

  //router.post('/classify', function(req, res, next) {
    // DON'T return the hardcoded response after implementing the backend
   // let response = ["shoe", "red", "nike"];

  // Your code starts here //
   var file = req.files.file;
   var filename = file.name;
  try{
    file.mv(`public//images//${filename}`, async(err) => {
      if(err){
        res.json({
          "labels": err
        });
        
      }else{
        res.json({
          "labels": 'image upload successful'
          
        });
      }
  })
  }catch(err){
    console.log(err);
  }
   
  // Your code ends here //
 
  
});


module.exports = router;
