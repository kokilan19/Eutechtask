var express = require('express');
var router = express.Router();
var AWS = require('aws-sdk');
const fs = require('fs');


router.post('/classify', function(req, res, next) {
  // DON'T return the hardcoded response after implementing the backend
  let response = ["shoe", "red", "nike"];
console.log(req.files.file)
  // Your code starts here //
//s3
const s3 = new AWS.S3({
  accessKeyId:"AKIARAR74F5B2ZJFROOU",
  secretAccessKey:"58t6FYfBVhi0FhEKFwxOWExsgASY3dtg6EHAPcVP",
 
  region: process.env.AWS_REGION
});



  
    // const { name, image, content } = req.body;
    // image data
    // const base64Data = new Buffer.from(image.replace(/^data:image\/\w+;base64,/, ''), 'base64');
    // const type = image.split(';')[0].split('/')[1];

    // const slug = slugify(name);
    // let category = new Category({ name, content, slug });
    const client = new AWS.Rekognition();

    const params = {
        
       
        
        Bucket: 'hacker-data',
        Key: `category/${req.files.file.md5}`,
        Body: req.files.file.data,
        ACL: 'public-read',
        ContentEncoding: 'base64',
        
        ContentType: `image/jpeg`
    };

    s3.upload(params, (err, data) => {
        if (err) {
            console.log(err);
            res.status(400).json({ error: 'Upload to s3 failed' });
            return;
        }
      

        //posted by
        res.json({
          "labels": "image upload sucess"
        });
    });

    


  // Your code ends here //

  
});

module.exports = router;
